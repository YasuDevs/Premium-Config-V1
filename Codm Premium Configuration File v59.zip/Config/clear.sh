
rm -rf /data/data/com.garena.game.codm/files/tss_tmp/* &> /dev/null
chmod -R 000 /data/data/com.garena.game.codm/files/tss_tmp &> /dev/null
rm -rf /data/data/com.vng.codmvn/files/tss_tmp/* &> /dev/null
chmod -R 000 /data/data/com.vng.codmvn/files/tss_tmp &> /dev/null
rm -rf /data/data/com.activision.callofduty.shooter/files/tss_tmp/* &> /dev/null
chmod -R 000 /data/data/com.activision.callofduty.shooter/files/tss_tmp &> /dev/null
rm -rf /storage/emulated/0/y.log
rm -rf /data/user/0/com.excelliance.dualaid/files
rm -rf /data/user/0/com.excelliance.dualaid/gameplugins/com.activision.callofduty.shooter/files/ano_tmp
rm -rf /data/user/0/com.excelliance.dualaid/gameplugins/com.garena.game.codm/files/ano_tmp
rm -rf /data/user/0/com.tencent.mmm/files
rm -rf /data/user/0/com.tencent.mmm/com.pubg.imobile/data/user/0/com.activision.callofduty.shooter/files/ano_tmp
rm -rf /data/user/0/com.tencent.mmm/com.pubg.imobile/data/user/0/com.garena.game.codm/files/ano_tmp


touch /data/user/0/com.excelliance.dualaid/files
touch /data/user/0/com.excelliance.dualaid/gameplugins/com.activision.callofduty.shooter/files/ano_tmp
touch /data/user/0/com.excelliance.dualaid/gameplugins/com.garena.game.codm/files/ano_tmp
touch /data/user/0/com.tencent.mmm/files
touch /data/user/0/com.tencent.mmm/com.pubg.imobile/data/user/0/com.activision.callofduty.shooter/files/ano_tmp
touch /data/user/0/com.tencent.mmm/com.pubg.imobile/data/user/0/com.garena.game.codm/files/ano_tmp